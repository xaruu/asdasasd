from django.urls import path
from .views import home, dos

urlpatterns = [
    path('', home, name='home'),
    path('dos/', dos, name='dos'),
]
