from django.urls import path
from .views import home, dos, ingresar, salir

urlpatterns = [
    path('', home, name='home'),
    path('dos/', dos, name='dos'),
    path('ingresar/', ingresar, name='ingresar'),
    path('salir/', salir, name='salir'),
]
