from django.apps import AppConfig


class DosConfig(AppConfig):
    name = 'dos'
